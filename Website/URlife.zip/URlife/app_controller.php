<?php
/**
 * Application level Controller
 *
 * This file is application-wide controller file. You can put all
 * application-wide controller-related methods here.
 *
 * PHP versions 4 and 5
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright 2005-2010, Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright 2005-2010, Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       cake
 * @subpackage    cake.app
 * @since         CakePHP(tm) v 0.2.9
 * @license       MIT License (http://www.opensource.org/licenses/mit-license.php)
 */

/**
 * Application Controller
 *
 * Add your application-wide methods in the class below, your controllers
 * will inherit them.
 *
 * @package       cake
 * @subpackage    cake.app
 */
class AppController extends Controller {
    var $components = array('Auth','Session');

    function beforeFilter() {

        $this->Auth->allow('display');
        $this->Auth->authError = 'Please login to view page';
        $this->Auth->loginError = 'Incorrect username or password';
        //$this->Auth->autoRedirect = false;

        $this->set('admin',$this->_isAdmin());
        $this->set('vendor',$this->_isVendor());
        $this->set('user',$this->_isUser());
        $this->set('logged_in',$this->_loggedIn());
        $this->set('users_username',$this->_usersUsername());
        
		/*
        if($this->_isAdmin()){
            echo('admin');
            $this->Auth->loginRedirect = array('controller'=>'users','action'=>'index');
        }else if($this->_isVendor()){
            echo('vendor');
            $this->Auth->loginRedirect = array('controller'=>'establishment','action'=>'index');
        }else if($this->_isUser()){
            echo('user');
            $this->Auth->loginRedirect = array('controller'=>'events','action'=>'index');;
        }*/
       
		$this->Auth->loginAction = array('controller'=>'users','action'=>'login');
        $this->Auth->loginRedirect = array( 'controller' => 'pages', 'action' => 'display');
        $this->Auth->logoutRedirect = array('controller'=>'pages','action'=>'display');


    }

    function _isAdmin() {
        $admin = FALSE;
        if($this->Auth->user('role') == 'admin') {
            $admin = TRUE;
        }
        return $admin;
    }

    function _isVendor() {
        $vendor = FALSE;
        if($this->Auth->user('role') == 'vendor') {
            $vendor = TRUE;
        }
        return $vendor;
    }

    function _isUser() {
        $user = FALSE;
        if($this->Auth->user('role') == 'user') {
            $user = TRUE;
        }
        return $user;
    }

    function _loggedIn() {
        $logged_in = FALSE;
        if($this->Auth->user()) {
            $logged_in = TRUE;
        }
        return $logged_in;
    }

    function _usersUsername() {
        $users_username = NULL;
        if($this->Auth->user()) {
            $users_username = $this->Auth->user('username');
        }
        return $users_username;
    }
}










