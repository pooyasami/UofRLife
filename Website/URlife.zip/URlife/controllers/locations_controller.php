<?php
/**
 * locations_controller.php
 * Event controller
 * Created by Luis Pizarro on 
 * Copyright 2011 University of Regina. All rights reserved.
 * 
 * Static content controller.
 * This file will render views from views/events/
 * PHP versions 4 and 5
 */

class LocationsController extends AppController {

	/**
	 * 
	 * This variable is used to make the data transfer between the Location model
	 * and the controller
	 * @var String Name of the model being controlled
	 */
	var $name = 'Locations';


}
?>