<?php

/**
 * events_controller.php
 * Event controller
 * Created by Luis Pizarro on 
 * Copyright 2011 University of Regina. All rights reserved.
 * 
 * Static content controller.
 * This file will render views from views/events/
 * PHP versions 4 and 5
 */


class EventsController extends AppController {

	/**
	 * 
	 * This variable is used to make the data transfer between the Event model
	 * and the controller
	 * @var String Name of the model being controlled
	 */
	var $name = 'Events';
	
	/**
	 * 
	 * The modification of the default paginate variable allows this controller to paginate
	 * certain variables filtering the results by a specific argument. In this case we are
	 * paginating other models within this model. These new models also have a specific way
	 * of being paginated. The entity model is used to find all the event belonging to a
	 * specific user. The Event model is instatiated in order to paginate it in time_start 
	 * descendent mode. 
	 * @var unknown_type
	 */
	var $paginate = array(
		'Entity' => array('conditions' => array('Entity.user_id' => 'Auth.User.id')),
		'Event' => array('order' => array('Event.time_start' => 'desc')),
		'Establishment'
	);

	/**
	 * (non-PHPdoc)
	 * @see AppController::beforeFilter()
	 */
    function beforeFilter() {
        parent::beforeFilter();
        $this->Auth->allow('index','view');
    }

    /**
     * 
     * This function compiles the view of a particular event
     * @param $id id of the event shown
     */
	function view($id = null) {
		
		if (!$id) {
			$this->Session->setFlash(__('Invalid event', true));
			$this->redirect(array('action' => 'index'));
		 }
		/*
		 * Recursive is set to 2 to be able to see deeper into the hirarchical structure of the
		 * event model
		 */
		$this->Event->recursive = 2;
		$this->set('event', $this->Event->read(null, $id));
		$user_id = $this->Session->read('Auth.User.id');
		
		/*
		 * Decides wether the "Add Feedback" link will show up
		 */
		$value = $this->Event->read();
		$flag = FALSE;
		
        if($this->Auth->user()){
            if($user_id == $value['Entity']['user_id']){
            	$flag = TRUE;
            	$this->set('flag',$flag);
            }
            $this->set('flag',$flag);
        }else{
        	$this->set('flag',$flag);
        };

		$this->set("title_for_layout","View event");
		
		/*
		 * Loads the subscription model to be able to count how many people are attending the
		 * event shown on the screen
		 */
		$this->loadModel('Subscription');
		$count = $this->Subscription->find('count',array('conditions' => array('Subscription.event_id' => $id)));
		$this->set('count',$count);
		
		/*
		 * Loads the id of the user logged in and viewing the page
		 */
		$user_id = $this->Session->read('Auth.User.id');
		
		/*
		 * This following code modifies the button subscribed/unsubscribed.
		 * It does this by checking on the table of subscription. If the user logged in is found
		 * in the table with the same event_id as the event being shown, the unsubscribe button is displayed.
		 * Otherwise the subscribe button is shown
		 */
		$subscribed = 0;
		$subscribed = $this->Subscription->find('first',array('conditions' => array('Subscription.event_id' => $id,'Subscription.user_id' => $user_id)));
		$this->set('subscribed',$subscribed);
		$subsid = $subscribed['Subscription']['id'];
		$this->set('subsid',$subsid);

	}

	/**
	 * 
	 * This function adds an event. Similar to establishmnet, an entity needs to be created before
	 * the event gets created. Once is created and a location is assigned the event can be created
	 */
	function add() {
	
		if (!empty($this->data)) {
				/*
				 * Loading and creating the entity
				 */
                $this->loadModel('Entity');
			    $this->Entity->create();

                $value = $this->Entity->set(array('user_id'=>$this->Session->read('Auth.User.id'), 'location_id'=>$this->data['Event']['location'],'type'=>'EVENT'));
			    $this->Entity->save($value);

			    /*
			     * Then the event can be created
			     */
			    $this->Event->create();
			    $entity_id = $this->Entity->getLastInsertId();
			    $this->data['Event']['entity_id'] = $entity_id; 
			    $this->Event->set($this->data);
			    	    
			    if ($this->Event->save($this->data)) {
				    $this->Session->setFlash(__('The event has been saved', true));
				    $this->redirect(array('action' => 'view',$this->Event->getLastInsertID()));
			    } else {
				    $this->Session->setFlash(__('The event could not be saved. Please, try again.', true));
			    }
		}

        $entities = $this->Event->Entity->find('list');
		$this->set(compact('entities'));

        $user_id = $this->Session->read('Auth.User.id');
        $this->set('id', $user_id);

        $this->loadModel('Location');
        $locations = $this->Location->find('list');
        $this->set('locations',$locations);
        
        $type = array('party'=>'Party','presentation'=>'Presentation', 'sport'=>'Sport', 'fair'=>'Fair', 'food'=>'Food');
		$this->set('type',$type);
        
        $this->set("title_for_layout","Add event");
    }

    /**
     * 
     * This function allows for editing an event
     * @param $id id of the event being edited
     */
	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid event', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->Event->save($this->data)) {
				$this->Session->setFlash(__('The event has been saved', true));
				$this->redirect(array('action' => 'view',$id));
			} else {
				$this->Session->setFlash(__('The event could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Event->read(null, $id);
		}
		$entities = $this->Event->Entity->find('list');
		$this->set(compact('entities'));
		
		$this->set("title_for_layout","Edit event");
	}

	/**
	 * 
	 * This function deletes an event from the application
	 * @param $id id of the event being deleted
	 */
	function delete($id = null) {
		
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for event', true));
			$this->redirect(array('action'=>'index'));
		}
		
		if ($this->Event->delete($id)) {
			/*
			 * If someone is subscribed to this event, it deletes the entry of the 
			 * subscription in the subscription table
			 */
			$this->loadModel('Subscription');
			$this->Subscription->create();
			$this->Subscription->deleteAll(array('Subscription.event_id' => $id));
						
			$this->Session->setFlash(__('Event deleted', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Event was not deleted', true));
		$this->redirect(array('action' => 'index'));
		
		$this->set("title_for_layout","Delete event");
	}
	
	/**
	 * 
	 * This function lists all the events
	 * @param $type This variable holds the type of the event
	 */
	function index($type = 'all') {
		$this->Event->recursive = 2;
		/*
		 * This variable allows for viewing the events of a particular building
		 */
		$location_id = $this->params['url']['location'];
		
		/*
		 * if a building id is passed through the url, the events are filtered. Else,
		 * all events are shown
		 */
		if ($location_id){
	        $events = $this->paginate('Event',array('Entity.location_id' => $location_id));
	        $this->set('events',$events);	    
		}else if (!($type == 'all')){
			if($type=='food'){
				$this->set('events', $this->paginate('Event',array('Event.type' => 'food')));
			}else if($type == 'presentation'){
				$this->set('events', $this->paginate('Event',array('Event.type' => 'presentation')));
			}else if($type == 'sport'){
				$this->set('events', $this->paginate('Event',array('Event.type' => 'sport')));
			}else if($type == 'fair'){
				$this->set('events', $this->paginate('Event',array('Event.type' => 'fair')));
			}else if($type == 'party'){
				$this->set('events', $this->paginate('Event',array('Event.type' => 'party')));
			}
		}else if($type == 'all'){
			$this->set('events', $this->paginate());
		}	
		
		$this->set("title_for_layout","All events");
	}
	
	/**
	 * 
	 * Displays the events created by user logged in
	 */
	function myindex() {
		$this->Event->recursive = 2;
		$user_id = $this->Session->read('Auth.User.id');
		$events = $this->paginate('Event',array('Entity.user_id' => $user_id)); //Paginates the Event model filtering the second parameter as a condiction
		$this->set('events',$events);
		$this->set("title_for_layout","My events");
	}

}
?>