<?php

/**
 * eventfeedbacks_controller.php
 * Eventfeedback controller
 * Created by Luis Pizarro on 
 * Copyright 2011 University of Regina. All rights reserved.
 * 
 * Static content controller.
 * This file will render views from views/eventfeedbacks/
 * PHP versions 4 and 5
 */

class EventfeedbacksController extends AppController {

	/**
	 * 
	 * This variable is used to make the data transfer between the Eventfeedback model
	 * and the controller
	 * @var String Name of the model being controlled
	 */
	var $name = 'Eventfeedbacks';
	
	/**
	 * 
	 * The modification of the default paginate variable allows this controller to paginate
	 * certain variables filtering the results by a specific argument. Such 
	 * eventfeedback id in this case
	 * @var unknown_type
	 */
	var $paginate = array(
		'Eventfeedback' => array('order' => array('Eventfeedback.id' => 'asc'))
	);
	
	/**
	 * (non-PHPdoc)
	 * @see AppController::beforeFilter()
	 */
	function beforeFilter() {
        parent::beforeFilter();
    }

	/**
	 * 
	 * This function creates an event feedback.
	 * @param unknown_type $event_id
	 */
	function add($event_id = null) {
		
		if (!empty($this->data)) {
			$this->Eventfeedback->create();
			if ($this->Eventfeedback->save($this->data)) {
				$this->Session->setFlash(__('The feedback has been saved', true));
                $this->redirect(array('controller'=>'events','action'=>'view',$this->data['Eventfeedback']['event_id']));
			} else {
				$this->Session->setFlash(__('The feedback could not be saved. Please, try again.', true));
			}
		}
        /*
         * Send the post_id to the view to use in the form. This is to add the feedback to an
         * event already being seen
         */
        $this->set('event_id', $event_id);

		$events = $this->Eventfeedback->Event->find('list');
		$this->set(compact('events'));
		
		/*
		 * Extracts the user id from the session to log the feedback
		 */
		$user = $this->Session->read('Auth.User.username');
        $this->set('user', $user);
		
        /*
         * Creates an array of options for the user to rate the event.
         * This array is then saved in a variable named feedbackrate to be passed to the view
         */
		$feedbackrate = array('Awesome!!!'=>'Awesome','Good!!'=>'Good','Not bad'=>'Not bad','Fail!'=>'Fail');
		$this->set('feedbackrate',$feedbackrate);
	}

	/**
	 * 
	 * This function lets the admin edit the feedback
	 * @param $id id of the feedback to be edited
	 */
	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid eventfeedback', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->Eventfeedback->save($this->data)) {
				$this->Session->setFlash(__('The feedback has been saved', true));
				$this->redirect(array('action' => 'view',$id));
			} else {
				$this->Session->setFlash(__('The feedback could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Eventfeedback->read(null, $id);
		}
		$events = $this->Eventfeedback->Event->find('list');
		$this->set(compact('events'));
		
		$this->set('eventfeedback', $this->Eventfeedback->read(null, $id));
		
		$feedbackrate = array('Awesome!!!'=>'Awesome','Good!!'=>'Good','Not bad'=>'Not bad','Fail!'=>'Fail');
		$this->set('feedbackrate',$feedbackrate);
		
		$rating = $this->data['Eventfeedback']['rate'];
		$this->set('rating',$rating);
	}

	/**
	 * 
	 * Function lets the admin delete a feedback
	 * @param $id id of the feedback being deleted
	 */
	function delete($id = null) {
		
		$value = $this->Eventfeedback->read();
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for Feedback', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->Eventfeedback->delete($id)) {
			$this->Session->setFlash(__('Feedback deleted', true));
			$this->redirect(array('controller'=>'events','action'=>'view',$value['Eventfeedback']['event_id']));
		}
		$this->Session->setFlash(__('Feedback was not deleted', true));
		$this->redirect(array('action' => 'index'));
	}
	
	/**
	 * 
	 * This function list all the feedbakcs of a particular event
	 * @param $id id number of the event whose feedbacks are listed
	 */
	function thisfeedbacks($id = null) {
		$fbacks = $this->paginate('Eventfeedback',array('Eventfeedback.id' => $id)); 
		$this->set('fbacks',$fbacks);
	}
}
?>