<?php

/**
 * establishmentitems_controller.php
 * Establishmentitems controller
 * Created by Luis Pizarro on 
 * Copyright 2011 University of Regina. All rights reserved.
 * 
 * Static content controller.
 * This file will render views from views/establishmentitems/
 * PHP versions 4 and 5
 */

class EstablishmentitemsController extends AppController {
	/**
	 * 
	 * This variable is used to make the data transfer between the Establishmentitem model
	 * and the controller
	 * @var String Name of the model being controlled
	 */
	var $name = 'Establishmentitems';
    
	/**
	 * (non-PHPdoc)
	 * @see AppController::beforeFilter()
	 */
	function beforeFilter() {
        parent::beforeFilter();
        $this->Auth->allow('view');
    }

    /**
     * 
     * This function lets the user see a particular establishment item on a separate page
     * @param $id 
     * 	This is the id of the establishmnet item to be displayed
     */
	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid establishmentitem', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('establishmentitem', $this->Establishmentitem->read(null, $id));
		
		$user_id = $this->Session->read('Auth.User.id');	//reads the user_id of user logged in
		$this->Establishmentitem->recursive = 2;			//establishes the recursive view stage to 2 for further data access
		$value = $this->Establishmentitem->read();
		$flag = FALSE;										//flag used to control display items in the view
		
		/*
		 * the following if/else statement sets the value for the flag in order to control what
		 * can be seen by a user logged in or not. 
		 */
        if($this->Auth->user()){
            if($user_id == $value['Establishment']['Entity']['user_id']){
            	$flag = TRUE;
            	$this->set('flag',$flag);
            }
            $this->set('flag',$flag);
        }else{
        	$this->set('flag',$flag);
        };
	}

	/**
	 * 
	 * This function allows the vendor to add items to their menu
	 * @param int $establishment_id
	 */
	function add($establishment_id=null) {
		if (!empty($this->data)) {
			$this->Establishmentitem->create();
			if ($this->Establishmentitem->save($this->data)) {
				$this->Session->setFlash(__('The item has been saved', true));
				$this->redirect(array('controller'=>'establishments','action'=>'view',$this->data['Establishmentitem']['establishment_id']));
			} else {
				$this->Session->setFlash(__('The item could not be saved. Please, try again.', true));
			}
		}
		$this->set('establishment_id',$establishment_id);
		$this->set(compact('establishments'));
		$this->set("title_for_layout","Add item");
	}

	/**
	 * 
	 * This function allows the vendor to edit a menu item
	 * @param int $id
	 *  ID of the menu item being edited
	 */
	function edit($id = null) {
		/*
		 * Check for the data to be empty int he form and makes sure that a valid id is passed
		 * to the function. If any of the two cases is true redirects user to the index of items
		 */
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid item', true));
			$this->redirect(array('action' => 'index'));
		}
		/*
		 * If data isnt empty, it is then stored in the database. Then the user is redirected to the
		 * view of the item just entered
		 */
		if (!empty($this->data)) {
			if ($this->Establishmentitem->save($this->data)) {
				$this->Session->setFlash(__('The menu item has been saved', true));
				$this->redirect(array('action' => 'view',$id));
			} else {
				$this->Session->setFlash(__('The menu item could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Establishmentitem->read(null, $id);
		}
		$establishments = $this->Establishmentitem->Establishment->find('list');
		$this->set(compact('establishments'));
		
		$this->set('establishmentitem', $this->Establishmentitem->read(null, $id));
		
		/*
		 * Establishes the name of the page
		 */
		$this->set("title_for_layout","Edit item");
	}

	/**
	 * 
	 * Allows the vendor to delete an item from their menu
	 * @param int $id
	 * ID of the menu item being deleted
	 */
	function delete($id = null) {
		
		$value = $this->Establishmentitem->read();
		
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for item', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->Establishmentitem->delete($id)) {
			$this->Session->setFlash(__('Menu item deleted', true));
			$this->redirect(array('controller'=>'establishments','action'=>'view',$value['Establishment']['id']));
		}
		$this->Session->setFlash(__('Item was not deleted', true));
		$this->redirect(array('action' => 'index'));
		
	}
	
	/**
	 * 
	 * This function lets the vendor list all the menu items being created by him/herself.
	 * This allows for an easier look and feel of the items stored int he menu
	 */
	function myindexitems() {
		/*
		 * The Establishment model is first loaded. Then we store all the vendor names on an array
		 * and only choose the one that matches the vendor being logged in at the moment.
		 * We then display all the menu items that belong to this vendor.
		 */
		$this->loadModel('Establishment');
		$value = $this->Establishment->find('first',array('Establishment.vendor'));	
		$vendor = $value['Establishment']['vendor'];
		$data = $this->paginate(array('Establishment.vendor'=>$vendor));
		$this->set('establishmentitems',$data);
		
	}
}
?>