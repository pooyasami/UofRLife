<?php

/**
 * entities_controller.php
 * Entity controller
 * Created by Luis Pizarro on 
 * Copyright 2011 University of Regina. All rights reserved.
 * 
 * Static content controller.
 * This file will render views from views/entities/
 * PHP versions 4 and 5
 */

class EntitiesController extends AppController {

	var $name = 'Entities';

	/**
	 * Implements the add entity function when creating an event, establishment or vmachine.
	 * This function gets only called from the event, establishment and vmachine controllers. 
	 */
	function add() {
		if (!empty($this->data)) {
			$this->Entity->create();
			if ($this->Entity->save($this->data)) {
				$this->Session->setFlash(__('The entity has been saved', true));
				$this->redirect(array('controller'=>'events','action'=>'add'));
			} else {
				$this->Session->setFlash(__('The entity could not be saved. Please, try again.', true));
			}
		}
		$users = $this->Entity->User->find('list');
		$locations = $this->Entity->Location->find('list');
		$this->set(compact('users', 'locations'));
	}

	/**
	 * 
	 * Implements the edit entity function when the user edits the location of an event, establishment or
	 * vmachine. The admin user type is the only able to edit the user_id field of any entity.
	 * 
	 * @param $id null $id
	 * 		Id number of the entity to be edited
	 */
	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid entity', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->Entity->save($this->data)) {
				$this->Session->setFlash(__('The entity has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The entity could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Entity->read(null, $id);
		}
		$users = $this->Entity->User->find('list');
		$locations = $this->Entity->Location->find('list');
		$this->set(compact('users', 'locations'));
	}

	/**
	 * 
	 * Implements the delete entity function when the user deletes the location of an event, establishment or
	 * vmachine. The admin user is the only one able to delete entities related to vmachines and establishments.
	 * Unless the vendor or vmachine owner wants to delete their own entity. Regular users can delete their own
	 * entity related to an event.
	 * @param $id null $id
	 * 		Id number of the entity to be edited
	 */
	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for entity', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->Entity->delete($id)) {
			$this->Session->setFlash(__('Entity deleted', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Entity was not deleted', true));
		$this->redirect(array('action' => 'index'));
	}

}
?>