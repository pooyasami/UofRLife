<?php

/**
 * establishmentfeedbacks_controller.php
 * Establishmentfeedbacks controller
 * Created by Luis Pizarro on 
 * Copyright 2011 University of Regina. All rights reserved.
 * 
 * Static content controller.
 * This file will render views from views/establishmentfeedbacks/
 * PHP versions 4 and 5
 */

class EstablishmentfeedbacksController extends AppController {
	/**
	 * 
	 * This variable is used to make the data transfer between the Establishmentfeedback model
	 * and the controller
	 * @var String Name of the model being controlled
	 */
	var $name = 'Establishmentfeedbacks';

	/**
	 * (non-PHPdoc)
	 * @see AppController::beforeFilter()
	 */
	function beforeFilter() {
        parent::beforeFilter();
    }
	/**
	 * 
	 * Compiles an index for all feedbacks for all establishments.
	 * Currently not used by any user.
	 */
	function index() {
		$this->Establishmentfeedback->recursive = 0;
		$this->set('establishmentfeedbacks', $this->paginate());
		
		
	}
	
	/**
	 * 
	 * This function compiles the view of the feedback for a particular establishment feedback.
	 * The ID of the feedback is past on to the function, then it is processed and shown in the
	 * view.ctp for the establishmentfeedbacks model
	 * @param int $id
	 * 	This argument represents the establishmentfeedback ID number 
	 */
	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid establishmentfeedback', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('establishmentfeedback', $this->Establishmentfeedback->read(null, $id));
	}

	/**
	 * 
	 * This function process the addition of an establishment feedback to a particular establishment
	 * The argument being past to the function represents the ID of the establishment to which
	 * the feedback is being added on. If no information is stored in $this->data the add.ctp view
	 * is executed asking the user to enter information in the form. Once the information is entered
	 * and passed through the $this->data variable, the data is added to the $establishment_id
	 * provided and saved in the database
	 * @param unknown_type $establishment_id
	 * 	Represent the ID of the establishment 
	 */
	function add($establishment_id=null) {
			
		if (!empty($this->data)) {
			$this->Establishmentfeedback->create();
			if ($this->Establishmentfeedback->save($this->data)) {
				$this->Session->setFlash(__('The feedback has been saved', true));
				$this->redirect(array('controller'=>'establishments','action'=>'view',$this->data['Establishmentfeedback']['establishment_id']));
			} else {
				$this->Session->setFlash(__('The feedback could not be saved. Please, try again.', true));
			}
		}
		
		$this->set('establishment_id',$establishment_id);
		
		
		$establishments = $this->Establishmentfeedback->Establishment->find('list');
		$this->set(compact('establishments'));
		
		/**
		 * 
		 * Loads up the user session variables to register who the feedback was left by
		 * @var ArrayObject
		 */
		$user = $this->Session->read('Auth.User.username');
        $this->set('user', $user);
		
        /**
         * 
         * Array of options when rating the establishment.
         * @var ArrayObject Array of String objects
         */
		$feedbackrate = array('Awesome!!!'=>'Awesome','Good!!'=>'Good','Not bad'=>'Not bad','Fail!'=>'Fail');
		$this->set('feedbackrate',$feedbackrate);
	}

	/**
	 * 
	 * Allows the user to edit a feedback. This is usually only accessed by the admin,
	 * unless some modification needs to be implemented to allow other to access this.
	 * Same as the add function, the form gets generated with existing data populated on it,
	 * then the user performs the changes and submits the changes. Once this data is submitted
	 * the system catches this data and saves it in the database.
	 * @param $id
	 * 	This argument holds the ID of the feedback to be edited
	 */
	function edit($id = null) {
		
		if (!$id && empty($this->data)) {
			/*
			 * This message is shown if invalid data has been entered in the form
			 */
			$this->Session->setFlash(__('Invalid feedback', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->Establishmentfeedback->save($this->data)) {
				/*
				 * Confirms that data has been properly stored
				 */
				$this->Session->setFlash(__('The feedback has been saved', true));
				$this->redirect(array('action' => 'view',$id));
			} else {
				/*
				 * Message prompts the user with a warning message, letting her/him know
				 * that data has not been saved.
				 */
				$this->Session->setFlash(__('The feedback could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Establishmentfeedback->read(null, $id);
		}
		$establishments = $this->Establishmentfeedback->Establishment->find('list');
		$this->set(compact('establishments'));
		
		$this->set('establishmentfeedback', $this->Establishmentfeedback->read(null, $id));
		
		/*
		 * Set the name of the page being viewed
		 */
		$this->set("title_for_layout","Edit feedback");
	}

	/**
	 * 
	 * This function is in charged of deleting a given establishment feedback.
	 * The argument $id, is the ID number of the feedback being deleted
	 * @param int $id
	 * 	ID number of the feedback being deleted
	 */	
	function delete($id = null) {
		
		/*
		 *  Stores the array object of Establishmentfeedback into a variable.
		 *  This is done to later redirect the user to the view page of the 
		 *  establishment being edited.
		 */
		$value = $this->Establishmentfeedback->read();
		
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for feedback', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->Establishmentfeedback->delete($id)) {
			$this->Session->setFlash(__('Feedback deleted', true));
			$this->redirect(array('controller' => 'establishments','action'=>'view',$value['Establishment']['id']));
		}
		$this->Session->setFlash(__('Feedback was not deleted', true));
		$this->redirect(array('action' => 'index'));

	}
	
	/**
	 * 
	 * This function is accessed by all vendors and admins.
	 * It basically list all the feedbacks left by users for a particular vendor.
	 * If vendor is logged in and executes this function, all the feedbacks left for that vendor will
	 * be populated on the screen
	 */
	function myindexfeedbacks() {
		
		/*
		 * The model for establishment is loaded first for access. Then the we need to
		 * pull all the establishments that the vendor has. Usually there can only be one
		 * establishment per vendor. Then we save the information related to that establishment
		 * on a array object and paginate it for display. 
		 */
		$this->loadModel('Establishment');
		$value = $this->Establishment->find('first',array('Establishment.vendor'));	
		$vendor = $value['Establishment']['vendor'];
		$data = $this->paginate(array('Establishment.vendor'=>$vendor));
		$this->set('establishmentfeedbacks',$data);

	}
}
?>