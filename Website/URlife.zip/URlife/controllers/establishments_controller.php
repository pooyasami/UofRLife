<?php

/**
 * establishment_controller.php
 * Establishment controller
 * Created by Luis Pizarro on 
 * Copyright 2011 University of Regina. All rights reserved.
 * 
 * Static content controller.
 * This file will render views from views/establishment/
 * PHP versions 4 and 5
 */

class EstablishmentsController extends AppController {

	/**
	 * 
	 * This variable is used to make the data transfer between the Establishmentitem model
	 * and the controller
	 * @var String Name of the model being controlled
	 */
	var $name = 'Establishments';
	
	/**
	 * (non-PHPdoc)
	 * @see AppController::beforeFilter()
	 */
	function beforeFilter() {
        parent::beforeFilter();
        $this->Auth->allow('index','view');
    }
	
    /**
     * 
     * This function indexes all the establishments stored in the database
     */
	function index() {
		$this->Establishment->recursive = 0;
		$this->set('establishments', $this->paginate());
	}
	
	/**
	 * 
	 * Function lets user view detail specification of a prticular establishment.
	 * @param $id
	 * 	Represents the id of the establishment being displayed
	 */
	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid establishment', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('establishment', $this->Establishment->read(null, $id));
		
		$value = $this->Establishment->read();
					
		$flag = FALSE;	//variable utilized to control the displayed elements on the screen

		/*
		 * This flag is set depending on who is logged in and controls the items viewed
		 * on the screen
		 */
        if($this->Auth->user()){	
        	$user_id = $this->Session->read('Auth.User.id');
     	
            if($user_id == $value['Entity']['user_id']){
            	$flag = TRUE;
            	$this->set('flag',$flag);
            }
            $this->set('flag',$flag);
        }else{
        	$this->set('flag',$flag);
        };
  
	}

	/**
	 * 
	 * This function lets the admin to add establishments around the university. In order to
	 * create a establishment an entity needs to be created before with user id and location id.
	 * Hence the admin creates first the user who the establishment will be assigned to then creates
	 * the establishment. Assign the user and location to the establishment and now the information 
	 * for the establishment can be entered
	 */
	function add() {
		
		/*
		 * The vendor must have already been created before creating the establishment.
		 */		
		if (!empty($this->data)) {
			
			/*
			 * First create the entity. With the appropiate values such as correct user id, location and VENDOR type.
			 */
			$this->loadModel('Entity');
			$this->Entity->create();
			$value = $this->Entity->set(array('user_id'=>$this->data['Establishment']['user_id'],'location_id'=>$this->data['Establishment']['location'],'type'=>'VENDOR'));
			$this->Entity->save($value);
			
			/*
			 * Then we are ready to create the establishment, with an entity id same as the last one
			 * inserted
			 */
			$this->Establishment->create();
			$entity_id = $this->Entity->getLastInsertId();
			$this->data['Establishment']['entity_id'] = $entity_id;
			$this->Establishment->set($this->data);
			
			/*
			 * We now save the data colected in the form and save it into the satabase.
			 * Appropiate flash messages will be displayed depending on the status of the system
			 */
			if ($this->Establishment->save($this->data)) {
				$this->Session->setFlash(__('The establishment has been saved', true));
				$this->redirect(array('action' => 'view',$this->Establishment->getLastInsertID()));
			} else {
				$this->Session->setFlash(__('The establishment could not be saved. Please, try again.', true));
			}
		}
		
		/*
		 * We also need to have a list of entities to choose from when saving the establishment.
		 * This information is hidden in the form (not displayed on the screen)
		 */
		$entities = $this->Establishment->Entity->find('list');
		$this->set(compact('entities'));
		
		/*
		 * We need to load the User model to pass the list of users available to be assigned
		 * to the establishment. This information is shown as a drop down menu
		 */
		$this->loadModel('User');
		$this->User->create();
		$users = $this->User->find('list',array('fields' => array('User.username')));
		$this->set('users',$users);
		
		/*
		 * A list of locations is loaded as well to be assigned to the establishment being created
		 * This information is shown as a drop down menu
		 */
		$this->loadModel('Location');
        $locations = $this->Location->find('list');
        $this->set('locations',$locations);
		
        /*
         * Sets the name of the page being displayed
         */
		$this->set('title_for_layout','Add establishment');
	}

	/**
	 * 
	 * This function lets the vendor edit the establishment assigned
	 * All the fields get populated with data extracted from the database, then the 
	 * vendor is able to edit it.
	 * @param $id
	 * 	This is the id of the establishment needed to be edited
	 */
	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid establishment', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->Establishment->save($this->data)) {
				$this->Session->setFlash(__('The establishment has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The establishment could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Establishment->read(null, $id);
		}
		$entities = $this->Establishment->Entity->find('list');
		$this->set(compact('entities'));
		
		$this->set('establishment_id',$id);
	}

	/**
	 * 
	 * This function lets the vendor or admin to delete an establishment from the application
	 * @param $id
	 * 	This is the id of the establishment to be deleted
	 */
	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for establishment', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->Establishment->delete($id)) {
			$this->Session->setFlash(__('Establishment deleted', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Establishment was not deleted', true));
		$this->redirect(array('action' => 'index'));
	}
}
?>